package xarxes;

public class Xarxes {

    private LT teclat = new LT(); // Clase para leer el teclado
    private int tamañoAlfabeto; // Para saber el tamaño del alfabeto

    public Xarxes(int s) {
        this.tamañoAlfabeto = s;
    }
    
    //Calculamos todos los parámetros posibles de un código
    public void calcularCodigo() {
        System.out.println("IMPORTANTE! PROBABILIDADES EN PORCENTAJES");
        //Variables
        double entropia = 0;
        double probabilidad = 0;
        double sumaProbabilidades = 0;

        int longitud = 0;
        double k = 0;
        double Lprima = 0;
        double eficiencia = 0;
        //Primero calculamos L
        for (int i = 0; i < tamañoAlfabeto; i++) {
            System.out.println("Introduce la probabilidad y la longitud de la palabra " + i + ":");
            System.out.println("Probabilidad:");
            // Leemos la probabilidad de la palabra
            probabilidad = teclat.llegirReal() / 100;
            sumaProbabilidades += probabilidad;
            //Calculamos la entropía
            entropia += probabilidad * Math.log(1 / probabilidad) / Math.log(2);
            System.out.println("Longitud:");
            // Ahora leemos el número de símbolos de la palbra
            longitud = teclat.llegirSencer();
            //Calculamos la K
            k += Math.pow(2, -longitud);
            // Calculamos L prima
            Lprima += (double) probabilidad * longitud;
        }
        System.out.println("La suma de todas las probabilidades es: " + sumaProbabilidades);
        System.out.println("Entropia: " + entropia + " bits");
        System.out.println("La K es: " + k);
        System.out.println("L prima: " + Lprima);

        //Ahora sí, calculamos la eficiencia
        eficiencia = entropia / Lprima;
        System.out.println("La eficiencia es: " + eficiencia + " bits/binit");

    }

    public void calcularInformacionMutua(int N) {
        double entropia = 0;
        double Xi[]= new double[tamañoAlfabeto];
        double Yj[]=new double[N];
        double YjXi;
        double total = 0;
        System.out.println("IMPORTANTE! PROBABILIDADES EN PORCENTAJES");
        //Este for es para pedir las probabilidades de X
        System.out.println("Ahora te vamos a pedir todas las probabilidades de X");
        for(int i=0;i<tamañoAlfabeto;i++){
            System.out.println("Introduce la probabilidad de X" + (i+1));
            Xi[i] = teclat.llegirReal()/100;
            entropia += Xi[i] * Math.log(1 / Xi[i]) / Math.log(2);
        }
        
        //Este for es para pedir las probabilidades de y
        System.out.println("Ahora te vamos a pedir todas las probabilidades de Y");
        for(int i=0;i<N;i++){
            System.out.println("Introduce la probabilidad de Y" + (i+1));
            Yj[i] = teclat.llegirReal()/100;
        }
        
        //Este for lo calcula todo
        for (int i = 0; i < tamañoAlfabeto; i++) {
            
            for (int j = 0; j < N; j++) {

                System.out.println("Introduce la probabilidad de (Y"+(j+1)+"|X"+(i+1)+")");
                YjXi = teclat.llegirReal()/100;
                if(YjXi != 0){
                    total += Xi[i] * YjXi * log2(YjXi / Yj[j]);
                }
                

            }

        }
        System.out.println("La entropia es : "+entropia);
        System.out.println("La Información Mutua total es :"+total);
        System.out.println("El término de equivocación es :"+(entropia-total));
    }

    private static Double log(double num, int base) {
        return (Math.log10(num) / Math.log10(base));
    }
    private static double log2(double x){
    return Math.log(x) / Math.log(2);
}
    
}
