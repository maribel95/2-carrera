
package xarxes;

public class Principal {

    public static void main(String[] args) {
         Xarxes entropia = new Xarxes(8);
        
         entropia.calcularCodigo();
         
        
    }
    
}
