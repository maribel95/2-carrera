package paquete;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class Util extends JPanel {

    private int n = 4;
    private double height = 800;
    private double width = 800;
    private JTextField jta;
    private JLabel jl, coo;
    private BufferedImage reina, result;
    private JComboBox combox, comboy;
    private JButton changen, changexy;
    private int x, y;
    private int[][] matriz;
    private boolean resultado;

    public Util() {
        /**
         * *****************************************
         * DECLARACIONES DE JFRAME *****************
         */
        this.setSize(1000, 829);
        this.setLayout(null);

        /**
         * *****************************************
         * DECLARACIONES INICIALES *****************
         */
        x = 0;
        y = 0;
        matriz = new int[n][n];
        //rellenar matriz
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                matriz[i][j] = 0;
            }
        }
        showMatriz();

        /**
         * *****************************************
         * DECLARACIONES DE LA INTERFAZ
         * *****************************************
         */
        try {
            reina = ImageIO.read(new File("img/queen1.png"));
        } catch (IOException ex) {
        }
        jl = new JLabel("Introduzca N:");
        add(jl);
        jl.setFont(new Font("Arial", 0, 18));
        jl.setBounds(810, 30, 180, 30);
        coo = new JLabel("Elija coordenadas: ");
        add(coo);
        coo.setFont(new Font("Arial", 0, 18));
        coo.setBounds(810, 150, 180, 30);
        combox = new JComboBox();
        add(combox);
        combox.setBounds(810, 180, 80, 30);
        combox.setBackground(Color.WHITE);
        comboy = new JComboBox();
        add(comboy);
        comboy.setBounds(900, 180, 80, 30);
        comboy.setBackground(Color.WHITE);
        changen = new JButton("Aplicar");
        add(changen);
        changen.setBounds(810, 100, 175, 30);
        changen.setBackground(Color.WHITE);
        changen.addActionListener((ActionEvent e) -> {
            try {
                    n = Integer.parseInt(jta.getText());
                    if (n > 8) {
                        n = 8;
                        jta.setText("8");
                    } else if (n < 1) {
                        n = 1;
                        jta.setText("1");
                    }
                    x = 0;
                    y = 0;
                    updateCombo();
                    updateMatriz();
                    //showMatriz();
                    resultado = false;
                    repaint();
                
            } catch (NullPointerException | NumberFormatException ex) {
            }
        });
        changexy = new JButton("Calcular");
        add(changexy);
        changexy.setBounds(810, 220, 175, 30);
        changexy.setBackground(Color.WHITE);
        changexy.addActionListener((ActionEvent e) -> {
            x = combox.getSelectedIndex();
            y = comboy.getSelectedIndex();
            updateMatriz();
            //showMatriz();
            resultado = poner(n - 1);
            repaint();
        });
        updateCombo();
        jta = new JTextField();
        add(jta);
        jta.setFont(new Font("Arial", 0, 18));
        jta.setBounds(810, 60, 175, 30);
    }

    @Override
    public void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g;
        double locHeight = height / n;
        double locWidth = width / n;
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                if ((j + i) % 2 == 0) {
                    g2.setColor(Color.WHITE);
                } else {
                    g2.setColor(Color.LIGHT_GRAY);
                }
                Rectangle2D r = new Rectangle2D.Double(i * locHeight, j * locWidth, locHeight, locWidth);
                g2.fill(r);
            }
        }
        g2.fillRect(800, 0, 200, 800);
        g2.setColor(Color.BLACK);
        g2.drawLine(800, 0, 800, 800);
        //miramos donde dibujamos las reinas
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                if (matriz[j][i] == 1) {
                    g2.drawImage(reina, i * (int) locHeight, j * (int) locWidth, (int) locWidth, (int) locHeight, null);
                }
            }
        }
        try {
            if (!resultado) {
                result = ImageIO.read(new File("img/not.png"));
                g2.drawImage(result, 830, 400, 140, 140, null);
            } else {
                result = ImageIO.read(new File("img/ok.png"));
                g2.drawImage(result, 830, 400, 140, 140, null);
            }
        } catch (IOException e) {
        }
    }

    //algoritmo recursivo que pone una reina y comprueba si esta correcta
    private boolean poner(int N) {
        //showMatriz();
        if (N == 0) {
            return true;
        }
        //buscar casilla no ocupada i no atacada
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                if (!checkAttack(i, j) && matriz[i][j] != 1) {
                    matriz[i][j] = 1;
                    if (poner(N - 1) == true) {
                        return true;
                    }
                    matriz[i][j] = 0;
                }
            }
        }
        return false;
    }

    //comprueba si la posicion elegida es atacada por alguna reina
    private boolean checkAttack(int i, int j) {
        int k, l;
        //mirar horizontales y verticales
        for (k = 0; k < n; k++) {
            if (matriz[i][k] == 1 || matriz[k][j] == 1) {
                return true;
            }
        }
        //mirar diagonales
        for (k = 0; k < n; k++) {
            for (l = 0; l < n; l++) {
                if (k + l == i + j || k - l == i - j) {
                    if (matriz[k][l] == 1) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    /**
     * *****************************************
     * METODOS DE LA INTERFAZ *****************************************
     */
    //actualiza los selectores de la posicion inicial
    public void updateCombo() {
        combox.removeAllItems();
        comboy.removeAllItems();
        for (int i = 0; i < n; i++) {
            combox.addItem(i + 1);
            comboy.addItem(i + 1);
        }
    }

    //actualiza la matriz
    private void updateMatriz() {
        matriz = new int[n][n];
        matriz[x][y] = 1;
    }

    //muestra la matriz por la consola
    public void showMatriz() {
        System.out.println("\n\n\n\n*** MATRIZ ***");
        for (int i = 0; i < n; i++) {
            System.out.print("[");
            for (int j = 0; j < n; j++) {
                System.out.print(matriz[i][j] + " ");
            }
            System.out.print("]");
            System.out.print("\n");
        }
    }
}
