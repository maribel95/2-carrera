package paquete;

import javax.swing.JFrame;

public class Projecte3 extends JFrame {

    Util i = new Util();
    
    public Projecte3() {
        this.setTitle("Problema de las N reinas");
        this.setSize(1000, 829);
        this.getContentPane().setLayout(null);
        this.setResizable(false);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setLocationRelativeTo(null);
        this.setVisible(true);
        add(i);
    }
    
    public static void main(String[] args) {
        new Projecte3();
    }
    
}
