/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prac;

import javax.swing.JOptionPane;

class ListaAsignaturas implements ListaElementos {

    private Asignatura primero;
    private int longitud;

    public ListaAsignaturas() {
        primero = null;
        longitud = 0;
    }

    @Override
    public int getLongitud() {
        return longitud;
    }

    public void crear(String id, int c, String curso, int sel) {

        Asignatura nuevo = new Asignatura(id, c, curso);
        switch (sel) {
            case 0:
                nuevo = new AsignaturaObligatoria(id, c, curso, getNumCreditos());
                break;
            case 1:
                nuevo = new AsignaturaOptativa(id, c, curso, getPerfil());
                break;
        }
        if (primero == null) {
            primero = nuevo;
            longitud = 1;
            return;
        }
        if (c < primero.getCodigo()) {
            nuevo.setSiguiente(primero);
            primero = nuevo;
        }
        Asignatura apuntador = primero;
        while (apuntador.getSiguiente() != null && c > apuntador.getCodigo()) {
            apuntador = apuntador.getSiguiente();
        }
        if (apuntador.getSiguiente() == null) {
            apuntador.setSiguiente(nuevo);
            longitud++;
        } else {
            Asignatura aux = apuntador.getSiguiente();
            apuntador.setSiguiente(nuevo);
            nuevo.setSiguiente(aux);
            longitud++;
        }
    }

    public void eliminar(int c) {
        if (primero == null) {
            return;
        }
        if (primero.getCodigo() == c) {
            primero = primero.getSiguiente();
            longitud--;
            return;
        }
        Asignatura apuntador = primero;
        while (apuntador != null && apuntador.getSiguiente() != null
                && apuntador.getSiguiente().getCodigo() != c) {
            apuntador = apuntador.getSiguiente();
        }
        if (apuntador.getSiguiente() == null) {
            return;
        }
        Asignatura aux = apuntador.getSiguiente();
        apuntador.setSiguiente(apuntador.getSiguiente().getSiguiente());
        aux.setSiguiente(null);
        aux.eliminar();
        longitud--;
    }


    public Asignatura getAsignatura(int indice) {
        Asignatura nodo;
        int i = 0;
        nodo = primero;
        while (nodo != null && i < indice) {
            nodo = nodo.getSiguiente();
            i++;
        }
        if (i > indice) {
            return null;
        }
        return nodo;
    }

    public int getNumCreditos() {
        int n;
        try {
            n = Integer.parseInt(JOptionPane.showInputDialog("Introduzca el numero de creditos"));
            return n;
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "El numero de creditos sera 0");

            return 0;
        }
    }

    public String getPerfil() {
        String[] sel = {"Teorico", "Practico"};
        String s = (String) JOptionPane.showInputDialog(null, "Elija el perfil:",
                "Perfil", JOptionPane.QUESTION_MESSAGE, null, sel, sel[0]);
        return s;
    }

}
