/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prac;

public class Curso implements Elemento {

    protected String nombre;
    protected int codigo;
    protected Curso sig;
    protected ListaAsignaturas asignaturas;
    protected String tipo;

    public Curso(String s, int i) {
        nombre = s;
        codigo = i;
        sig = null;
        asignaturas = new ListaAsignaturas();
    }

    @Override
    public String getNombre() {
        return nombre;
    }

    public int getCodigo() {
        return codigo;
    }

    @Override
    public String toString() {
        return "Nom=" + nombre + " Cod=" + codigo + " Tipo=" + tipo;
    }

    @Override
    public void setSiguiente(Object e) {
        sig = (Curso) e;
    }

    @Override
    public Curso getSiguiente() {
        return sig;
    }

    public ListaAsignaturas getListaAsignaturas() {
        return asignaturas;
    }

    public void eliminar() {
        for (int i = 0; i < asignaturas.getLongitud(); i++) {
            asignaturas.eliminar(asignaturas.getAsignatura(i).getCodigo());
        }
    }
}
