/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prac;

public class Asignatura implements Elemento {

    protected String nombre;
    protected int codigo;
    protected Asignatura sig;
    protected ListaAlumnos alumnos;
    protected String tipo;
    protected String curso;

    public Asignatura(String s, int i, String c) {
        nombre = s;
        codigo = i;
        curso = c;
        sig = null;
        alumnos = new ListaAlumnos();
    }

    @Override
    public String getNombre() {
        return nombre;
    }

    public int getCodigo() {
        return codigo;
    }

    @Override
    public String toString() {
        return "Nom=" + nombre + " Cod=" + codigo + " Curso=" + curso + " Tipo=" + tipo;
    }

    @Override
    public void setSiguiente(Object e) {
        sig = (Asignatura) e;
    }

    @Override
    public Asignatura getSiguiente() {
        return sig;
    }

    public ListaAlumnos getListaAlumnos() {
        return alumnos;
    }

    public void eliminar() {
        for (int i = 0; i < alumnos.getLongitud(); i++) {
            alumnos.eliminar(alumnos.getAlumno(i).getNombre());
        }
    }

}
