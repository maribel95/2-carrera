/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prac;

public class AsignaturaObligatoria extends Asignatura {

    private int creditos;

    public AsignaturaObligatoria(String s, int i, String curso, int cr) {
        super(s, i, curso);
        this.creditos = cr;
        tipo = "Obligatoria";
    }

    @Override
    public String toString() {
        return "Nom=" + nombre + " Cod=" + codigo + " Curso=" + curso + " Tipo=" + tipo + " Creditos=" + creditos;
    }

}
