/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prac;

public class ListaCursos implements ListaElementos {

    private Curso primero;
    private int longitud;

    public ListaCursos() {
        primero = null;
        longitud = 0;
    }

    @Override
    public int getLongitud() {
        return longitud;
    }

    public void crear(String s, int id, int sel) {
        Curso nuevo = new Curso(s, id);
        switch (sel) {
            case 0:
                nuevo = new CursoFPMecanica(s, id);
                break;
            case 1:
                nuevo = new CursoFPElectronica(s, id);
                break;
            case 2:
                nuevo = new CursoFPInformatica(s, id);
                break;
            case 3:
                nuevo = new CursoBach1(s, id);
                break;
            case 4:
                nuevo = new CursoBach2(s, id);
                break;
        }
        if (primero == null) {
            primero = nuevo;
            longitud = 1;
            return;
        }
        if (id < primero.getCodigo()) {
            nuevo.setSiguiente(primero);
            primero = nuevo;
        }
        Curso apuntador = primero;
        while (apuntador.getSiguiente() != null && id > apuntador.getCodigo()) {
            apuntador = apuntador.getSiguiente();
        }
        if (apuntador.getSiguiente() == null) {
            apuntador.setSiguiente(nuevo);
            longitud++;
        } else {
            Curso aux = apuntador.getSiguiente();
            apuntador.setSiguiente(nuevo);
            nuevo.setSiguiente(aux);
            longitud++;
        }
    }

    public void eliminar(int i) {
        if (primero == null) {
            return;
        }
        if (primero.getCodigo() == i) {
            primero = primero.getSiguiente();
            longitud--;
            return;
        }
        Curso apuntador = primero;
        while (apuntador != null && apuntador.getSiguiente() != null
                && apuntador.getSiguiente().getCodigo() != i) {
            apuntador = apuntador.getSiguiente();
        }
        if (apuntador.getSiguiente() == null) {
            return;
        }
        Curso aux = apuntador.getSiguiente();
        apuntador.setSiguiente(apuntador.getSiguiente().getSiguiente());
        aux.setSiguiente(null);
        aux.eliminar();
        longitud--;
    }

    public Curso getcurso(int indice) {
        Curso nodo;
        int i = 0;
        nodo = primero;
        while (nodo != null && i < indice) {
            nodo = nodo.getSiguiente();
            i++;
        }
        if (i > indice) {
            return null;
        }
        return nodo;
    }
}
