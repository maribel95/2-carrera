/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prac;

public class Alumno implements Elemento {

    private String dni;
    private String nombre;
    private Alumno sig;

    public Alumno(String id, String s) {
        dni = id;
        nombre = s;
        sig = null;
    }

    @Override
    public String getNombre() {
        return nombre;
    }

    public String getCodigo() {
        return dni;
    }

    @Override
    public String toString() {
        return "Dni=" + dni + " Nombre=" + nombre;
    }

    @Override
    public void setSiguiente(Object e) {
        sig = (Alumno) e;
    }

    @Override
    public Alumno getSiguiente() {
        return sig;
    }

}
