/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prac;

import javax.swing.JFrame;

public class Prac extends JFrame {
    
    private Interface i;
    
    public Prac () {
        this.setTitle("PRACTICA");
        this.setSize(1100,900);
        this.getContentPane().setLayout(null);
        this.setResizable(false);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setLocationRelativeTo(null);
        i=new Interface();
        add(i);
        
    }
            
            
    public static void main(String[] args) {
        new Prac().setVisible(true);
    }
    
}
