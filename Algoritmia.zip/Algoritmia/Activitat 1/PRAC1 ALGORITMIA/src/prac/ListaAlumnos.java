/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prac;

public class ListaAlumnos implements ListaElementos {

    private Alumno primero;
    private int longitud;

    public ListaAlumnos() {
        primero = null;
        longitud = 0;
    }

    @Override
    public int getLongitud() {
        return longitud;
    }

    public void crear(String id, String s) {
        Alumno nuevo = new Alumno(id, s);
        if (primero == null) {
            primero = nuevo;
            longitud = 1;
            return;
        }
        if (s.compareTo(primero.getNombre()) < 0) {
            nuevo.setSiguiente(primero);
            primero = nuevo;
        }
        Alumno apuntador = primero;
        while (apuntador.getSiguiente() != null && s.compareTo(apuntador.getNombre()) > 0) {
            apuntador = apuntador.getSiguiente();
        }
        if (apuntador.getSiguiente() == null) {
            apuntador.setSiguiente(nuevo);
            longitud++;
        } else {
            Alumno aux = apuntador.getSiguiente();
            apuntador.setSiguiente(nuevo);
            nuevo.setSiguiente(aux);
            longitud++;
        }
    }

    public void eliminar(String nombre) {
        if (primero == null) {
            return;
        }
        if (primero.getNombre().equals(nombre)) {
            primero = primero.getSiguiente();
            longitud--;
            return;
        }
        Alumno apuntador = primero;
        while (apuntador != null && apuntador.getSiguiente() != null
                && !apuntador.getSiguiente().getNombre().equals(nombre)) {
            apuntador = apuntador.getSiguiente();
        }
        if (apuntador.getSiguiente() == null) {
            return;
        }
        Alumno aux = apuntador.getSiguiente();
        apuntador.setSiguiente(apuntador.getSiguiente().getSiguiente());
        aux.setSiguiente(null);
        longitud--;
    }

    public Alumno getAlumno(int indice) {
        Alumno nodo;
        int i = 0;
        nodo = primero;
        while (nodo != null && i < indice) {
            nodo = nodo.getSiguiente();
            i++;
        }
        if (i > indice) {
            return null;
        }
        return nodo;
    }

    public Alumno getPrimero() {
        return primero;
    }
}
