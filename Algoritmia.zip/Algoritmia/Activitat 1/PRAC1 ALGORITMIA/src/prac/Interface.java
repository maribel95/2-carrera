package prac;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

public class Interface extends JPanel {

    /**
     * *****************************************
     * DECLARACIONES DE ELEMENTOS LOGICOS
     * *****************************************
     */
//declaracion de la lista principal de cursos
    ListaCursos listacursos;

//declaracion de modelo de lista
    DefaultListModel dlmcursos = new DefaultListModel();
    DefaultListModel dlmasign = new DefaultListModel();
    DefaultListModel dlmalumnos = new DefaultListModel();
    DefaultListModel dlmasignporalumno = new DefaultListModel();

    //actuales
    int cursoActual;
    int asignActual;
    int alumnoActual;

    //array doble para alumnos + array doble para asignaturas por alumno
    String[] arrAsignaturas;
    String[][] arrAlumnos;
    int iasignarr;//indice asignatura
    int ialumnarr;//indice asignatura
    int jalumnarr;//indice alumno

    //tipos de curso
    String[] tiposcurso = {"FP Mecanica", "FP Electronica", "FP Informatica",
        "1 Bachillerato", "2 Bachillerato"};
    //tipos de asignatura
    String[] tiposasign = {"Obligatoria", "Optativa"};

    /**
     * *****************************************
     * DECLARACIONES DE ELEMENTOS DE LA INTERFAZ
     * *****************************************
     */
    JLabel cursos, asign, alumnos, infocurso, infoasign, infoalumno, asignporalumno,
            infocursoVar, infoasignVar, infoalumnoVar,
            anadircurso, nombrecurso, idcurso, tipocurso,
            anadirasign, nombreasign, idasign, cursoasign, tipoasign,
            anadiralumno, nombrealumno, idalumno, asignalumno,
            elcurso, selelcurso,
            elasign, selelasign;
    JButton crearcurso, crearasign, crearalumno, elimcurso, elimasign;
    JTextField jtfcursonom, jtfcursoid, jtfasignnom, jtfasignid, jtfalumnonom, jtfalumnoid;
    JList<String> jlcursos, jlalumnos, jlasign, jlasignporalumno;
    JComboBox combotipocurso, combocurso, combotipoasign, comboasign, comboelimcurso, comboelimasign;

    public Interface() {
        //declaraciones contenedor
        setBackground(Color.WHITE);
        setLayout(null);
        setBounds(0, 0, 1200, 1000);
        //inicializacion lista cursos
        listacursos = new ListaCursos();

        //inicializacion arrays
        arrAsignaturas = new String[15];
        for (int i = 0; i < arrAsignaturas.length; i++) {
            arrAsignaturas[i] = "-";
        }
        arrAlumnos = new String[15][15];
        for (int i = 0; i < arrAlumnos.length; i++) {
            for (int j = 0; j < arrAlumnos[i].length; j++) {
                arrAlumnos[i][j] = "-";
            }
        }
        iasignarr = 0;
        ialumnarr = 0;
        jalumnarr = 0;

        /**
         * *****************************************
         * INICIALIZACION DE ETIQUETAS DE TEXTO
         * *****************************************
         */
        cursos = new JLabel("Cursos");
        asign = new JLabel("Asignaturas");
        alumnos = new JLabel("Alumnos");
        infocurso = new JLabel("Informacion del curso: ");
        infoasign = new JLabel("Informacion de la asignatura: ");
        infoalumno = new JLabel("Informacion del alumno: ");
        asignporalumno = new JLabel("Asignaturas del alumno");
        infocursoVar = new JLabel();
        infoasignVar = new JLabel();
        infoalumnoVar = new JLabel();
        anadircurso = new JLabel("Añadir curso");
        nombrecurso = new JLabel("Nombre: ");
        idcurso = new JLabel("ID: ");
        tipocurso = new JLabel("Tipo: ");
        anadirasign = new JLabel("Añadir asignatura");
        nombreasign = new JLabel("Nombre: ");
        idasign = new JLabel("ID: ");
        cursoasign = new JLabel("Curso: ");
        tipoasign = new JLabel("Tipo: ");
        anadiralumno = new JLabel("Añadir alumno");
        nombrealumno = new JLabel("Nombre: ");
        idalumno = new JLabel("DNI: ");
        asignalumno = new JLabel("Asignatura: ");
        elcurso = new JLabel("Eliminar curso");
        selelcurso = new JLabel("Seleccione: ");
        elasign = new JLabel("Eliminar asignatura");
        selelasign = new JLabel("Seleccione: ");
        /**
         * *****************************************
         * INICIALIZACION COMBO BOX *****************************************
         */
        combotipocurso = new JComboBox(tiposcurso);
        combocurso = new JComboBox();
        comboasign = new JComboBox();
        combotipoasign = new JComboBox(tiposasign);
        comboelimcurso = new JComboBox();
        comboelimasign = new JComboBox();
        /**
         * *****************************************
         * INICIALIZACION CAMPOS DE TEXTO
         * *****************************************
         */
        jtfcursonom = new JTextField();
        jtfcursoid = new JTextField();
        jtfasignnom = new JTextField();
        jtfasignid = new JTextField();
        jtfalumnonom = new JTextField();
        jtfalumnoid = new JTextField();
        /**
         * *****************************************
         * INICIALIACION BOTONES ****************************************
         */
        crearcurso = new JButton("Crear curso");
        crearasign = new JButton("Crear asignatura");
        crearalumno = new JButton("Matricular alumno");
        elimcurso = new JButton("Eliminar curso");
        elimasign = new JButton("Eliminar asignatura");
        /**
         * *****************************************
         * INICIALIZACION DE LISTAS GRAFICAS
         * *****************************************
         */
        jlcursos = new JList<>(dlmcursos);
        jlasign = new JList<>(dlmasign);
        jlalumnos = new JList<>(dlmalumnos);
        jlasignporalumno = new JList<>(dlmasignporalumno);
        /**
         * *****************************************
         * DECLARACIONES DE COMBO BOX *****************************************
         */
        add(combotipocurso);
        combotipocurso.setBounds(860, 130, 200, 25);
        combotipocurso.setFont(new Font("Arial", 0, 16));
        add(combotipoasign);
        combotipoasign.setBounds(860, 290, 200, 25);
        combotipoasign.setFont(new Font("Arial", 0, 16));
        add(combocurso);
        combocurso.setBounds(860, 320, 200, 25);
        combocurso.setFont(new Font("Arial", 0, 16));
        add(comboasign);
        comboasign.setBounds(860, 490, 200, 25);
        comboasign.setFont(new Font("Arial", 0, 16));
        add(comboelimcurso);
        comboelimcurso.setBounds(860, 590, 200, 25);
        comboelimcurso.setFont(new Font("Arial", 0, 16));
        add(comboelimasign);
        comboelimasign.setBounds(860, 690, 200, 25);
        comboelimasign.setFont(new Font("Arial", 0, 16));
        /**
         * *****************************************
         * DECLARACIONES DE CAMPOS DE TEXTO
         * *****************************************
         */
        add(jtfcursonom);
        jtfcursonom.setBounds(860, 70, 200, 25);
        jtfcursonom.setFont(new Font("Arial", 0, 16));
        add(jtfcursoid);
        jtfcursoid.setBounds(860, 100, 200, 25);
        jtfcursoid.setFont(new Font("Arial", 0, 16));
        add(jtfasignnom);
        jtfasignnom.setBounds(860, 230, 200, 25);
        jtfasignnom.setFont(new Font("Arial", 0, 16));
        add(jtfasignid);
        jtfasignid.setBounds(860, 260, 200, 25);
        jtfasignid.setFont(new Font("Arial", 0, 16));
        add(jtfalumnonom);
        jtfalumnonom.setBounds(860, 430, 200, 25);
        jtfalumnonom.setFont(new Font("Arial", 0, 16));
        add(jtfalumnoid);
        jtfalumnoid.setBounds(860, 460, 200, 25);
        jtfalumnoid.setFont(new Font("Arial", 0, 16));
        /**
         * *****************************************
         * DECLARACIONES DE ETIQUETAS DE TEXTO
         * *****************************************
         */
        add(cursos);
        cursos.setBounds(30, 50, 200, 30);
        cursos.setFont(new Font("Arial", 0, 16));
        add(asign);
        asign.setBounds(260, 50, 200, 30);
        asign.setFont(new Font("Arial", 0, 16));
        add(alumnos);
        alumnos.setBounds(490, 50, 200, 30);
        alumnos.setFont(new Font("Arial", 0, 16));
        add(infocurso);
        infocurso.setBounds(30, 350, 250, 30);
        infocurso.setFont(new Font("Arial", 0, 16));
        add(infoasign);
        infoasign.setBounds(30, 380, 250, 30);
        infoasign.setFont(new Font("Arial", 0, 16));
        add(infoalumno);
        infoalumno.setBounds(30, 410, 250, 30);
        infoalumno.setFont(new Font("Arial", 0, 16));
        add(asignporalumno);
        asignporalumno.setBounds(30, 450, 250, 30);
        asignporalumno.setFont(new Font("Arial", 0, 16));
        add(infocursoVar);
        infocursoVar.setBounds(260, 350, 500, 30);
        infocursoVar.setFont(new Font("Arial", 0, 16));
        add(infoasignVar);
        infoasignVar.setBounds(260, 380, 500, 30);
        infoasignVar.setFont(new Font("Arial", 0, 16));
        add(infoalumnoVar);
        infoalumnoVar.setBounds(260, 410, 500, 30);
        infoalumnoVar.setFont(new Font("Arial", 0, 16));
        add(anadircurso);
        anadircurso.setBounds(860, 40, 200, 30);
        anadircurso.setFont(new Font("Arial", 1, 16));
        anadircurso.setHorizontalAlignment(JLabel.CENTER);
        add(nombrecurso);
        nombrecurso.setBounds(760, 70, 200, 30);
        nombrecurso.setFont(new Font("Arial", 0, 16));
        add(idcurso);
        idcurso.setBounds(760, 100, 200, 30);
        idcurso.setFont(new Font("Arial", 0, 16));
        add(tipocurso);
        tipocurso.setBounds(760, 130, 200, 30);
        tipocurso.setFont(new Font("Arial", 0, 16));
        add(anadirasign);
        anadirasign.setBounds(860, 200, 200, 30);
        anadirasign.setFont(new Font("Arial", 1, 16));
        anadirasign.setHorizontalAlignment(JLabel.CENTER);
        add(nombreasign);
        nombreasign.setBounds(760, 230, 200, 30);
        nombreasign.setFont(new Font("Arial", 0, 16));
        add(idasign);
        idasign.setBounds(760, 260, 200, 30);
        idasign.setFont(new Font("Arial", 0, 16));
        add(tipoasign);
        tipoasign.setBounds(760, 290, 200, 25);
        tipoasign.setFont(new Font("Arial", 0, 16));
        add(cursoasign);
        cursoasign.setBounds(760, 320, 200, 30);
        cursoasign.setFont(new Font("Arial", 0, 16));
        add(anadiralumno);
        anadiralumno.setBounds(860, 400, 200, 30);
        anadiralumno.setFont(new Font("Arial", 1, 16));
        anadiralumno.setHorizontalAlignment(JLabel.CENTER);
        add(nombrealumno);
        nombrealumno.setBounds(760, 430, 200, 30);
        nombrealumno.setFont(new Font("Arial", 0, 16));
        add(idalumno);
        idalumno.setBounds(760, 460, 200, 30);
        idalumno.setFont(new Font("Arial", 0, 16));
        add(asignalumno);
        asignalumno.setBounds(760, 490, 200, 30);
        asignalumno.setFont(new Font("Arial", 0, 16));
        add(elcurso);
        elcurso.setBounds(860, 560, 200, 30);
        elcurso.setFont(new Font("Arial", 1, 16));
        elcurso.setHorizontalAlignment(JLabel.CENTER);
        add(selelcurso);
        selelcurso.setBounds(760, 590, 200, 30);
        selelcurso.setFont(new Font("Arial", 0, 16));
        add(elasign);
        elasign.setBounds(860, 660, 200, 30);
        elasign.setFont(new Font("Arial", 1, 16));
        elasign.setHorizontalAlignment(JLabel.CENTER);
        add(selelasign);
        selelasign.setBounds(760, 700, 200, 30);
        selelasign.setFont(new Font("Arial", 0, 16));
        /**
         * *****************************************
         * DECLARACIONES DE BOTONES *****************************************
         */
        add(crearcurso);
        crearcurso.setBounds(860, 160, 200, 25);
        crearcurso.setFont(new Font("Arial", 0, 16));
        crearcurso.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                crearCurso();
            }
        });
        add(crearasign);
        crearasign.setBounds(860, 350, 200, 25);
        crearasign.setFont(new Font("Arial", 0, 16));
        crearasign.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                crearAsignatura();
            }
        });
        add(crearalumno);
        crearalumno.setBounds(860, 520, 200, 25);
        crearalumno.setFont(new Font("Arial", 0, 16));
        crearalumno.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                crearAlumno();
            }
        });
        add(elimcurso);
        elimcurso.setBounds(860, 620, 200, 25);
        elimcurso.setFont(new Font("Arial", 0, 16));
        elimcurso.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                eliminarCurso();
            }
        });
        add(elimasign);
        elimasign.setBounds(860, 720, 200, 25);
        elimasign.setFont(new Font("Arial", 0, 16));
        elimasign.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                eliminarAsignatura();
            }
        });
        /**
         * *****************************************
         * DECLARACIONES DE LISTAS GRAFICAS
         * *****************************************
         */
        add(jlcursos);
        jlcursos.setBounds(30, 90, 200, 250);
        jlcursos.setFont(new Font("Arial", 0, 14));
        jlcursos.setBackground(Color.LIGHT_GRAY);
        jlcursos.addListSelectionListener(
                new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                int n = jlcursos.getSelectedIndex();
                if (n != -1) {
                    cursoActual = n;
                    actualizarListaAsignaturas();
                    mostrarInfoCurso();
                    dlmalumnos.clear();
                    dlmasignporalumno.clear();
                }
            }
        });
        add(jlasign);
        jlasign.setBounds(260, 90, 200, 250);
        jlasign.setFont(new Font("Arial", 0, 14));
        jlasign.setBackground(Color.LIGHT_GRAY);
        jlasign.addListSelectionListener(
                new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                int n = jlasign.getSelectedIndex();
                if (n != -1 && cursoActual <= listacursos.getLongitud()) {
                    asignActual = n;
                    actualizarListaAlumnos();
                    mostrarInfoAsignatura();
                    dlmasignporalumno.clear();
                }
            }

        });
        add(jlalumnos);
        jlalumnos.setBounds(490, 90, 200, 250);
        jlalumnos.setFont(new Font("Arial", 0, 14));
        jlalumnos.setBackground(Color.LIGHT_GRAY);
        jlalumnos.addListSelectionListener(
                new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                int n = jlalumnos.getSelectedIndex();
                if (n != -1) {
                    alumnoActual = n;
                    mostrarInfoAlumno();
                    actualizarListaAsignPorAlumno();
                }
            }

        });
        add(jlasignporalumno);
        jlasignporalumno.setBounds(30, 490, 200, 250);
        jlasignporalumno.setFont(new Font("Arial", 0, 14));
        jlasignporalumno.setBackground(Color.LIGHT_GRAY);
    }

    /**
     * *****************************************
     * FIN DEL METODO CONSTRUCTOR *****************************************
     */
    public void crearCurso() {
        try {
            if (jtfcursonom.getText().equals("")) {
                JOptionPane.showMessageDialog(null, "OPERACIÓN INCORRECTA");
                return;
            }
            listacursos.crear(jtfcursonom.getText(), Integer.parseInt(jtfcursoid.getText()), combotipocurso.getSelectedIndex());
            dlmcursos.clear();
            for (int i = 0; i < listacursos.getLongitud(); i++) {
                dlmcursos.addElement(listacursos.getcurso(i).getNombre());
            }
            actualizarCombos();
            dlmasign.clear();
            dlmalumnos.clear();
            actualizarListaAsignPorAlumno();
        } catch (NumberFormatException | NullPointerException e) {
            JOptionPane.showMessageDialog(null, "OPERACIÓN INCORRECTA");
        }
    }

    public void crearAsignatura() {
        try {
            int i = combocurso.getSelectedIndex();
            if (jtfasignnom.getText().equals("")) {
                JOptionPane.showMessageDialog(null, "OPERACIÓN INCORRECTA");
                return;
            }
            //creamos una asignatura obligatoria u optativa
            listacursos.getcurso(i).getListaAsignaturas().crear(jtfasignnom.getText(), Integer.parseInt(jtfasignid.getText()),
                    listacursos.getcurso(i).getNombre(),
                    combotipoasign.getSelectedIndex());

            if (cursoActual == i) {
                actualizarListaAsignaturas();
            }
            dlmalumnos.clear();
            actualizarArrayAsignaturas();
            actualizarArrayAlumnos();
            actualizarListaAsignPorAlumno();
        } catch (NumberFormatException | NullPointerException e) {
            JOptionPane.showMessageDialog(null, "OPERACIÓN INCORRECTA");
        }
    }

    public void crearAlumno() {
        try {
            int i = comboasign.getSelectedIndex();
            if (jtfalumnoid.getText().equals("") || jtfalumnonom.getText().equals("")) {
                JOptionPane.showMessageDialog(null, "OPERACIÓN INCORRECTA");
                return;
            }
            listacursos.getcurso(cursoActual).getListaAsignaturas().getAsignatura(i).getListaAlumnos().crear(jtfalumnoid.getText(), jtfalumnonom.getText());
            if (i == asignActual) {
                actualizarListaAlumnos();
            }
            actualizarArrayAlumnos();
            actualizarListaAsignPorAlumno();
        } catch (NumberFormatException | NullPointerException e) {
            JOptionPane.showMessageDialog(null, "OPERACIÓN INCORRECTA");
        }
    }

    public void eliminarCurso() {
        try {
            int n = comboelimcurso.getSelectedIndex();
            int codigo = listacursos.getcurso(n).getCodigo();
            listacursos.eliminar(codigo);
            dlmcursos.clear();
            for (int i = 0; i < listacursos.getLongitud(); i++) {
                dlmcursos.addElement(listacursos.getcurso(i).getNombre());
            }
            dlmasign.clear();
            cursoActual = listacursos.getLongitud() - 1;

            if (cursoActual >= 0) {
                for (int i = 0; i < listacursos.getLongitud(); i++) {
                }
            }
            actualizarCombos();
            dlmalumnos.clear();
            actualizarArrayAsignaturas();
            actualizarArrayAlumnos();
            dlmasignporalumno.clear();
        } catch (NumberFormatException | NullPointerException e) {
            JOptionPane.showMessageDialog(null, "OPERACIÓN INCORRECTA");
        }

    }

    public void eliminarAsignatura() {
        try {
            int n = comboelimasign.getSelectedIndex();
            int codigo = listacursos.getcurso(cursoActual).getListaAsignaturas().getAsignatura(n).getCodigo();
            listacursos.getcurso(cursoActual).getListaAsignaturas().eliminar(codigo);
            dlmasign.clear();
            for (int i = 0; i < listacursos.getcurso(cursoActual).getListaAsignaturas().getLongitud(); i++) {
                dlmasign.addElement(listacursos.getcurso(cursoActual).getListaAsignaturas().getAsignatura(i).getNombre());
            }
            asignActual = listacursos.getcurso(cursoActual).getListaAsignaturas().getLongitud() - 1;
            actualizarCombos();
            dlmalumnos.clear();
            actualizarArrayAsignaturas();
            actualizarArrayAlumnos();
            dlmasignporalumno.clear();
        } catch (NumberFormatException | NullPointerException e) {
            JOptionPane.showMessageDialog(null, "OPERACIÓN INCORRECTA");
        }
    }

    public void actualizarListaAsignaturas() {
        dlmasign.clear();
        for (int i = 0; i < listacursos.getcurso(cursoActual).getListaAsignaturas().getLongitud(); i++) {
            dlmasign.addElement(listacursos.getcurso(cursoActual).getListaAsignaturas().getAsignatura(i).getNombre());
        }
        actualizarCombos();
    }

    public void actualizarListaAlumnos() {
        dlmalumnos.clear();
        for (int i = 0; i < listacursos.getcurso(cursoActual).getListaAsignaturas().getAsignatura(asignActual).getListaAlumnos().getLongitud(); i++) {
            dlmalumnos.addElement(listacursos.getcurso(cursoActual).getListaAsignaturas().getAsignatura(asignActual).getListaAlumnos().getAlumno(i).getNombre());
        }
    }

    public void actualizarCombos() {
        combocurso.removeAllItems();
        comboasign.removeAllItems();
        comboelimcurso.removeAllItems();
        comboelimasign.removeAllItems();
        for (int i = 0; i < listacursos.getLongitud(); i++) {
            combocurso.addItem(listacursos.getcurso(i).getNombre());
            comboelimcurso.addItem(listacursos.getcurso(i).getNombre());
        }
        if (cursoActual < 0) {
            return;
        }
        for (int i = 0; i < listacursos.getcurso(cursoActual).getListaAsignaturas().getLongitud(); i++) {
            comboasign.addItem(listacursos.getcurso(cursoActual).getListaAsignaturas().getAsignatura(i).getNombre());
            comboelimasign.addItem(listacursos.getcurso(cursoActual).getListaAsignaturas().getAsignatura(i).getNombre());
        }
    }

    public void actualizarArrayAsignaturas() {
        //limpiar array
        for (int i = 0; i < arrAsignaturas.length; i++) {
            arrAsignaturas[i] = "-";
        }
        iasignarr = 0;
        //cargar datos
        for (int i = 0; i < listacursos.getLongitud(); i++) {
            for (int j = 0; j < listacursos.getcurso(i).getListaAsignaturas().getLongitud(); j++) {
                arrAsignaturas[iasignarr] = listacursos.getcurso(i).getListaAsignaturas().getAsignatura(j).getNombre();
                iasignarr++;
            }
        }
    }

    public void actualizarArrayAlumnos() {
        //limpiar array
        for (int i = 0; i < arrAlumnos.length; i++) {
            for (int j = 0; j < arrAlumnos[i].length; j++) {
                arrAlumnos[i][j] = "-";
            }
        }
        ialumnarr = 0;
        jalumnarr = 0;
        //cargar datos
        for (int i = 0; i < listacursos.getLongitud(); i++) {
            for (int j = 0; j < listacursos.getcurso(i).getListaAsignaturas().getLongitud(); j++) {
                for (int k = 0; k < listacursos.getcurso(i).getListaAsignaturas().getAsignatura(j).getListaAlumnos().getLongitud(); k++) {
                    arrAlumnos[ialumnarr][jalumnarr] = listacursos.getcurso(i).getListaAsignaturas().getAsignatura(j).getListaAlumnos().getAlumno(k).getNombre();
                    jalumnarr++;
                }
                jalumnarr = 0;
                ialumnarr++;
            }
        }
    }

    public void actualizarListaAsignPorAlumno() {
        //creamos un array auxiliar
        //una posicion corresponde a una asignatura
        int[] encontrado = new int[arrAsignaturas.length];
        for (int i = 0; i < encontrado.length; i++) {
            encontrado[i] = 0;
        }
        //borramos las asignaturas por alumno
        dlmasignporalumno.clear();
        if (listacursos.getLongitud() < 1) {
            return;
        }
        if (listacursos.getcurso(cursoActual).getListaAsignaturas().getLongitud() < 1) {
            return;
        }
        if (listacursos.getcurso(cursoActual).getListaAsignaturas().getAsignatura(asignActual).getListaAlumnos().getLongitud() < 1) {
            return;
        }
        //encontrar el nombre del alumno
        String nombre = listacursos.getcurso(cursoActual).getListaAsignaturas().getAsignatura(asignActual).getListaAlumnos().getAlumno(alumnoActual).getNombre();
        //buscar alumno en el array y ponemos a 1 el indice de la asignatura
        //en el caso de encontrarlo
        for (int i = 0; !"-".equals(arrAlumnos[i][0]); i++) {
            for (int j = 0; !"-".equals(arrAlumnos[i][j]); j++) {
                if (nombre.equals(arrAlumnos[i][j])) {
                    encontrado[i] = 1;
                }
            }
        }
        //recorremos el array y si el alumno es encontrado en la
        //asignarura "i", añadimos la asignatura a la lista
        for (int i = 0; i < encontrado.length; i++) {
            if (encontrado[i] == 1) {
                dlmasignporalumno.addElement(arrAsignaturas[i]);
            }
        }
    }

    public void mostrarInfoCurso() {
        infocursoVar.setText(listacursos.getcurso(cursoActual).toString());
    }

    public void mostrarInfoAsignatura() {
        infoasignVar.setText(listacursos.getcurso(cursoActual).getListaAsignaturas().getAsignatura(asignActual).toString());
    }

    public void mostrarInfoAlumno() {
        infoalumnoVar.setText(listacursos.getcurso(cursoActual).getListaAsignaturas().getAsignatura(asignActual).getListaAlumnos().getAlumno(alumnoActual).toString());
    }

}
