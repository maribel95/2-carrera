/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prac;

public class AsignaturaOptativa extends Asignatura {

    private String perfil;

    public AsignaturaOptativa(String s, int i, String curso, String p) {
        super(s, i, curso);
        tipo = "Optativa";
        perfil = p;
    }

    @Override
    public String toString() {
        return "Nom=" + nombre + " Cod=" + codigo + " Curso=" + curso + " Tipo=" + tipo + " Perfil=" + perfil;
    }

}
