/*
    GRUPO: Panas Operativos
    
    INTEGRANTES DEL GRUPO:
    Odilo Fortes Domínguez
    Sandu Bizu
    María Isabel Crespí Valero
*/


#include "my_lib.h"

// Funcion del main que calcula los datos de la pila.
int main(int argc, char *argv[]){
    //Declaraciones
	struct my_stack *pila;
	int *data;
	char *nombreFichero = argv[1];
   
    // Miramos si se ha introducido un nombre de fichero válido
	if (!nombreFichero) {
		// Imprimimos mensaje de error
		fprintf(stderr,"USAGE: %s filename\n",argv[0]);
		// Retornamos 0
		return 0;
	}
	// Leemos la pila del fichero
	pila = my_stack_read(nombreFichero);
	// Miramos si existe la pila
	if (!pila) { 
		//Imprimimos mensaje de error
		fprintf(stderr,"couldn't open stack file %s.\n",nombreFichero);
		// Retornamos 0
		return 0;
	}

    // Miramos qué tamaño tiene la pila
	int longitudPila = my_stack_len(pila);
	printf("Stack length: %d\n",longitudPila);
    // Variables para calcular las operaciones de los datos de la pila
	int sumatorio = 0;
	int max = 0;
	int min = INT_MAX;
    int contador = 0;
    
    while(pila->top){ 
		contador++;
        data = my_stack_pop(pila);
        printf("\n%d",*data);
        sumatorio += *data;
        // Miramos si es el máximo
		if (max < *data){
			max = *data; 
		}
		// O si es el mínimo
		if (min > *data){
			min = *data; 
		} 	                
    }
    // Calculamos la media
	int media = sumatorio/NUM_THREADS;
    printf("\nItems: %d Sum: %d Min: %d Max: %d Average: %d\n",contador,sumatorio,min,max,media); 
    return 0;
}