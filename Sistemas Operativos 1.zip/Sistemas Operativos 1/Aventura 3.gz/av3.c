/*
    GRUPO: Panas Operativos
    
    INTEGRANTES DEL GRUPO:
    Odilo Fortes Domínguez
    Sandu Bizu
    María Isabel Crespí Valero
*/
// Includes y constantes
#include "my_lib.h"

// Inicializamos semáforo
pthread_mutex_t semaforo = PTHREAD_MUTEX_INITIALIZER ;
// Declaramos la pila
struct my_stack *pila;

// Código
int main(int argc, char *argv[]){

//------------------------------------------        PREPARAMOS  LA PILA          ----------------------------------------------------
    //Guardamos el nombre del fichero que nos viene como argumento en argv
    char *nombreFichero = argv[1]; 
    int *datosCero;  
    int longitudPila;
    // Miramos si se ha introducido un nombre de fichero válido
	if (!nombreFichero) {
		fprintf(stderr,"USAGE: %s filename\n",argv[0]);
		return 0;
	}
    // Leemos la pila
    pila = my_stack_read(nombreFichero); 
    longitudPila = my_stack_len(pila); // Leemos la longitud
    printf("original stack length: %d\n",longitudPila);          
    if(pila){ // Si existe
        
        for(int i = longitudPila; i < MAXtamanoPila;i++){ // Miramos si la tenemos que rellenar o no
            datosCero = malloc(sizeof(int));
            *datosCero = 0;
            my_stack_push(pila,datosCero);
        }
        

    }else{ // Si no existe
        pila = my_stack_init(sizeof(int)); // La inicializamos
        for(int i = 0; i < MAXtamanoPila; i++){ // Inicializamos 10 espacios de datos
            datosCero = malloc(sizeof(int)); 
            *datosCero = 0;
            my_stack_push(pila,datosCero);
        }
    }
    longitudPila = my_stack_len(pila); // Leemos la longitud
    printf("new stack length: %d\n",longitudPila);


    //Imprimimos por pantalla los datos
	printf("Threads: %d, Iterations: %d\n", NUM_THREADS , N);
	

//-------------------------------------------       CREACIÓN HILOS       ---------------------------------------------------


    // En este array guardaremos los identificadores de los hilos
    pthread_t identificadores[ NUM_THREADS ];
    //Creamos 10 hilos.
    for( int i = 0 ; i <  NUM_THREADS ; i++ ){
        // Creamos los hilos
        pthread_create(&identificadores[i],NULL,worker,NULL);
        // Imprimimos los hilos creados
        printf("%d) Thread %ld created\n",i,(long)identificadores[i]);   
    }
    
    // Esperamos a que acaben todos los hilos
    for( int i = 0 ; i <  NUM_THREADS ; i++ ){
        pthread_join(identificadores[i],NULL);  
    } 
    // Y finalizamos
    printf("stack length: %d\n",longitudPila);
    printf("Written elements from stack to file:%d\n",my_stack_write(pila, nombreFichero));
    printf("Released bytes: %d\n",my_stack_purge(pila));
    printf("Bye from main.\n");
    pthread_exit(0);
    return 0;
}


//-------------------------------------------       FUNCION HILOS      ---------------------------------------------------
void *worker(void *ptr){    
    // Iteramos sobre los datos de la pila 1 millón de veces
    for( int i = 0 ; i < N ; i++ ){
        // Sección crítica 1
        pthread_mutex_lock (&semaforo);
        
        int *data = my_stack_pop(pila);

        pthread_mutex_unlock (&semaforo);

        (*data)++; //Incrementamos el valor la variable

        // Sección crítica 2
        pthread_mutex_lock (&semaforo);
        
        my_stack_push(pila,data);

        pthread_mutex_unlock (&semaforo);

    }
    pthread_exit(NULL); // Para salir de la función
}