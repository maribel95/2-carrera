#include "my_lib.h"

/*
    GRUPO: Panas Operativos
    
    INTEGRANTES DEL GRUPO:
    Odilo Fortes Domínguez
    Sandu Bizu
    María Isabel Crespí Valero
*/

/*
*****************************************************************
********             PRIMERA PARTE AVENTURA 1            ********
*******************************************************+*********
*/

// Función que mira cuántos carácteres tiene un String
size_t my_strlen(const char *str){
    // Inicializamos contador
    size_t len = 0;
    // Hasta que no encontremos el fin de String iremos recorriendo carácter a carácter
    while(*str++ != '\0'){
    len++;
    }
    return len;

}

// Función que compara dos Strings según el código ASCII de 
// los carácteres de ambos.
int my_strcmp(const char *str1, const char *str2){
    int longitud1,resultado;
    // La longitud nos servirá para hacernos una idea de hasta dónde seguir comparando
    longitud1=my_strlen(str1);

    resultado=0;
    // Haremos el for hasta que se acabe un string o se encuentre un carácter diferente
    for(int i=0;i<=longitud1 && resultado==0;i++){
        // Calculamos el resultado de restar en código ASCII ambos carácteres
        // Si el resultado es 0, es porque el carácter es el mismo
        resultado = (int)str1[i] - (int)str2[i];  
    }
    return resultado;
}





// Copia un String en otro.
char *my_strcpy(char *dest, const char *src){
    int longitud2;
 
    longitud2 = my_strlen(src);

 
    // Utilizaremos un puntero auxiliar para recorrer el String
    // y no perder el puntero dest
    char *aux = dest;
    for( int i = 0 ; i < longitud2 ; i++ ){
        //
        *aux++ = src[i];
    }
    //Para evitar posibles errores, siempre acabaremos con el símbolo de final de String.
    *aux = '\0';

    return dest;
}




// Copia n carácteres de un String en otro.
char *my_strncpy(char *dest, const char *src, size_t n){
    // Mediante un puntero auxiliar, iremos sobreescribiendo dest
    // con las n letras de src
    int longitud2 = my_strlen(src);
    // No se pueden copiar más letras de las que hay
    if(n > longitud2){
         n = longitud2;
    }
    // Puntero auxiliar para no perder dest
    char *aux = dest;
    for(int i=0;i<n ;i++){
         *aux++=src[i];
    }
    return dest;
}

// Contatena dos Strings
char *my_strcat(char *dest, const char *src){
    int longitud1, longitud2;

    longitud1 = my_strlen(dest);
    longitud2 = my_strlen(src);
    // Creamos un puntero auxiliar para no perder el puntero dest
    char *aux = dest;
    // Concatenamos src con dest
    for( int i = 0 ; i < longitud2 ; i++ ){
        // A partir de la posición donde acaba dest, empezamos a 
        // escribir los carácteres de src
        aux[i + longitud1] = src[i];
    }
    // Nos colocamos en la última posición del nuevo array
    aux[longitud1 + longitud2] = '\0';

    return dest;
}




/*
*****************************************************************
********             SEGUNDA PARTE AVENTURA 1            ********
*******************************************************+*********
*/


// Función para inicializar la pila con el tamaño de datos
// pasado por parámetro. Devolvemos el puntero a esa pila
struct my_stack *my_stack_init (int size){
    struct my_stack *puntero;
    // Reservamos espacio en memoria para el stack
    puntero = malloc(sizeof(struct my_stack));

    // Si la reserva de memoria ha ido bien
    if( puntero ){
        // Inicializamos sus variables 
        puntero->size = size;
        puntero->top = NULL;
    }
    // Devolvemos el puntero a la pila inicializada
    return puntero;
}


// Hacemos un push de la pila; es decir, metemos un elementos
// Devolvemos un valor según si ha salido bien o no la operación.
int my_stack_push (struct my_stack *stack, void *data){
    // La pila se tiene que haber inicializado
    // Variable para saber si ha ido bien la función o no
    int funciona = -1;
    if( stack != NULL ){
            // Se ha inicializado correctamente
            if( stack -> size > 0 ){
                struct my_stack_node *nuevonodo;
                // Guardamos espacio en memoria para el nuevo nodo
                nuevonodo = malloc( sizeof( struct my_stack_node ));
                // Comprobamos que se ha creado correctamente el nuevo nodo
                if( nuevonodo ){
                    // Ahora el puntero de datos del nuevo nodo apunta
                    // a los datos pasados por parámetro
                    nuevonodo -> data = data; // Metemos los datos
                    // Nuevonodo apunta al anterior primer elemento de 
                    // la lista
                    nuevonodo -> next = stack->top; 
                    // Y ahora first pasará a apuntar al nuevo elemento que
                    // hemos introducido
                    stack -> top = nuevonodo;
                    // Se ha efectuado un push correctamente

                    funciona  = 0;
                }
            }
    }
    return funciona;
}


// Hacemos un pop; es decir, sacamos un elemento de la pila
// Si ha salido bien, retornamos un puntero a los datos del 
// elementos eliminado.
void *my_stack_pop (struct my_stack *stack){
    // Miramos si la pila está vacía, porque entonces no podríamos
    // retornar ningún puntero a ningún valor
    void *datos = NULL;
    if( stack != NULL){
        if( stack -> top){
            
            // Puntero auxiliar que nos servirá para liberar memoria
            struct my_stack_node *aux = stack -> top;
            // Guardamos en un puntero los datos del elemento de la cima
            datos = stack -> top -> data;
            // Borramos ese elemento
            stack -> top = stack -> top ->next;
            free(aux);
            // Devolvemos el punteroa datos
            
        }
    }
    return datos;
}

// Calculamos el número de nodos de la pila
int my_stack_len (struct my_stack *stack){
    // Contador de elementos
    int contador=0;
    // Comprobamos que primero exista la pila
    if(stack != NULL){
        if( stack -> top ){
            // Utilizaremos un puntero auxiliar para hacer el recorrido
            // y así no perderemos el puntero principal de la pila
            struct my_stack_node *aux = stack -> top;
            while(aux){
                // Mientras no se acaben los elementos,
                // el contador va aumentando y vamos avanzando de nodo
                contador++;
                aux = aux -> next;

            }
        }
    }

    return contador;
}

// Borramos toda la pila, los nodos también. Devolvemos los bytes
// que hemos liberado.
int my_stack_purge(struct my_stack *stack){
    int bytesPila = sizeof(struct my_stack); // Tamaño de la pila
    int bytesNodos = sizeof(struct my_stack_node); // Tamaño del nodo
    int bytesDatos = stack->size; // Tamaño de los datos
    int bytesLiberados = 0; 
    int contador = 0; // Contador de nodos liberados      
    while(stack->top){
        free(my_stack_pop(stack));   // Vamos haciendo free de los nodos                    
        contador++;
    }
    free(stack);  // Finalmente liberamos el stack                    
    bytesLiberados = bytesPila + contador*(bytesDatos + bytesNodos); 
    return bytesLiberados;
}

// Escribimos el nodo en la lista. Nosotros hemos seguido la 
// estrategia de crear una pila auxiliar con los elementos al revés
// y así poder leerla luego correctamente.
int my_stack_write (struct my_stack *stack, char *filename){
    // Iniciamos nuestra pila auxiliar
    struct my_stack *pilaAuxiliar = my_stack_init(stack->size);
    // Para hacer el recorrido utilizaremos un puntero auxiliar
    struct my_stack_node *pAux = stack -> top;
    pilaAuxiliar = my_stack_init(stack->size);
    // Hacemos un bucle hasta haber metido todos los elementos
    // de la pila original en la nueva auxiliar
    for( int i = 0 ; i < my_stack_len(stack) ; i++ ){
        my_stack_push(pilaAuxiliar,pAux->data);
        pAux = pAux->next;
    }
    // Contador de elementos de la pila( devolverá en el return)
    int contador = 0;
    // Volvemos a colocar el puntero auxiliar
    pAux = pilaAuxiliar -> top;
    // Abrimos fichero y si no existe, lo creamos.
    int fd = open(filename,O_WRONLY | O_CREAT | O_TRUNC , S_IRUSR | S_IWUSR);
    // Miramos que no nos de ningún error el fichero
    if(fd != -1){
        // Escribimos un int que representará el tamaño de los datos de la pila
        write( fd, &stack->size, sizeof(pilaAuxiliar->size));
        // Ahora haremos un  recorrido de la pila para ir escribiendo
        // los datos de sus nodos en el fichero
        while( pAux ){
            //Escribimos los datos de los nodos
            write( fd, pAux->data, pilaAuxiliar->size);
            //Avanzamos de nodo
            pAux = pAux->next;
            contador++;
        }
    }else{
        // Si sucede algún fallo, retornamos un -1
        contador = -1;
    }
    // Importante cerrar el fichero
    close(fd);

    return contador;

}
// Función para leer la pila del fichero y volver a crear dicha pila
// en memoria.
struct my_stack *my_stack_read (char *filename){
    struct my_stack *stack;
    int fd = open(filename,O_RDONLY);
    int size; // Tamaño datos de los nodos de la pila
    void *p;  // Puntero a los datos de los nodos
    if( fd != -1){
        //Leemos el tamaño de los datos de la pila
        read( fd, &size, sizeof( int ) );
        // Inicializamos la nueva pila con dichos datos
        stack = my_stack_init(size);
        // Y guardamos memoria para esos datos
        p = malloc(size);
        // Ahora comienza el bucle para leer todos los demás elementos
        while ( read ( fd, p, size) > 0 ) { 
            // Vamos haciendo push de los nodos que vayamos leyendo
            my_stack_push(stack,p);
            // Guardamos memoria para todos los nodos
            p = malloc(size);
        }
    }else{
        // Si hay algún fallo, retornamos NULL
        return NULL;
    }

    // Cerramos el fichero
    close(fd);
    // Devolvemos el puntero a la nueva pila
    return stack;

}




// Fin