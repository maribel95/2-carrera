Miembros del grupo ( Panas Operativos ):

Odilo Fortes Domínguez
Sandu Bizu
María Isabel Crespí Valero

Consideraciones:

Los últimos detalles se han implementado en la etapa my_shell.
En general, no ha habido cambios posteriores de cada nivel, 
salvo quizás algunos detalles que mejoraban el funcionamiento,
o adición de comentarios.

No hay cabeceras, están todos los includes directamente en cada nivel.

El programa no tiene restricciones.

Ha sido una práctica muy entretenida!